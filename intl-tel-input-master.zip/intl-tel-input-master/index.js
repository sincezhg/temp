/* global module */
module.exports = require("./build/js/intlTelInput");
