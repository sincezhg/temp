//* Translated by: Google Translate.
export default {
  selectedCountryAriaLabel: "منتخب ملک",
  noCountrySelected: "کوئی ملک منتخب نہیں کیا گیا۔",
  countryListAriaLabel: "ممالک کی فہرست",
  searchPlaceholder: "تلاش کریں۔",
  zeroSearchResults: "کوئی نتیجہ نہیں",
  oneSearchResult: "1 نتیجہ ملا",
  multipleSearchResults: "${count} نتائج ملے",
};
