//* Translated by: Google Translate.
export default {
  selectedCountryAriaLabel: "Țara selectată",
  noCountrySelected: "Nicio țară selectată",
  countryListAriaLabel: "Lista țărilor",
  searchPlaceholder: "Căutare",
  zeroSearchResults: "Nici un rezultat gasit",
  oneSearchResult: "1 rezultat găsit",
  multipleSearchResults: "${count} rezultate găsite",
};
