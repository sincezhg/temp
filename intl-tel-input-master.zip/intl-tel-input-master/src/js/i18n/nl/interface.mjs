//* Translated by: Google Translate.
export default {
  selectedCountryAriaLabel: "Geselecteerd land",
  noCountrySelected: "Geen land geselecteerd",
  countryListAriaLabel: "Lijst met landen",
  searchPlaceholder: "Zoekopdracht",
  zeroSearchResults: "Geen resultaten gevonden",
  oneSearchResult: "1 resultaat gevonden",
  multipleSearchResults: "${count} resultaten gevonden",
};
