//* Translated by: Google Translate.
export default {
  selectedCountryAriaLabel: "País selecionado",
  noCountrySelected: "Nenhum país selecionado",
  countryListAriaLabel: "Lista de países",
  searchPlaceholder: "Procurar",
  zeroSearchResults: "Nenhum resultado encontrado",
  oneSearchResult: "1 resultado encontrado",
  multipleSearchResults: "${count} resultados encontrados",
};
