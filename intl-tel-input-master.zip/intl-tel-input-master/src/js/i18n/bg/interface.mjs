//* Translated by: Google Translate.
export default {
  selectedCountryAriaLabel: "Избрана държава",
  noCountrySelected: "Няма избрана държава",
  countryListAriaLabel: "Списък на страните",
  searchPlaceholder: "Търсене",
  zeroSearchResults: "Няма намерени резултати",
  oneSearchResult: "Намерен е 1 резултат",
  multipleSearchResults: "${count} намерени резултата",
};
