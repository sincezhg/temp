import countryTranslations from "./countries.mjs";
import interfaceTranslations from "./interface.mjs";

export default {...countryTranslations, ...interfaceTranslations};
