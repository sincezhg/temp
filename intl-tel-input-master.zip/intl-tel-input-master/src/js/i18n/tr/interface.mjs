//* Translated by: Google Translate.
export default {
  selectedCountryAriaLabel: "Seçilen ülke",
  noCountrySelected: "Hiçbir ülke seçilmedi",
  countryListAriaLabel: "Ülke listesi",
  searchPlaceholder: "Aramak",
  zeroSearchResults: "Sonuç bulunamadı",
  oneSearchResult: "1 sonuç bulundu",
  multipleSearchResults: "${count} sonuç bulundu",
};
