//* Translated by: Google Translate.
export default {
  selectedCountryAriaLabel: "Kiválasztott ország",
  noCountrySelected: "Nincs ország kiválasztva",
  countryListAriaLabel: "Országok listája",
  searchPlaceholder: "Keresés",
  zeroSearchResults: "Nincs találat",
  oneSearchResult: "1 találat",
  multipleSearchResults: "${count} találat",
};
